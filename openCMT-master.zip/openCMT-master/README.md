openCMT
===

A C++ library implementation of the tracking algorithm described in the paper "Consensus-based Matching and Tracking of Keypoints for Object Tracking" by Georg Nebehay and Roman Pflugfelder
